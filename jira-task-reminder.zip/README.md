# JIRA Task Reminder
This chrome extension helps you not to forget tasks on "In-Progress".

![Logo](images/img32.png)

### [Jira Task Reminder Mailer on Github](https://github.com/mohshbool/jira-task-reminder-mailer)
